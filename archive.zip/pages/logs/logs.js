//logs.js

Page({
  data: {
    logs: []
  },
  onLoad: function () {
    this.setData({
      
    })
  }
})
